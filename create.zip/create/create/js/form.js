
  function sendEmail(){
    let fname = document.getElementById('fname').value;
    let lname = document.getElementById('lname').value;
    let email = document.getElementById('email').value;
    let subject = document.getElementById('subject').value;
    let message = document.getElementById('message').value;
    message += '<br>First Name='+fname+'<br>Last Name='+lname;
    Email.send({
    Host: "smtp.gmail.com",
    Username : "preetimehra018@gmail.com",
    Password : "",
    To : "preetimehra018@gmail.com",
    From : "preetimehra018@gmail.com",
    Subject : subject,
    Body : message,
    }).then(
        message => alert(message)
      );

  }
